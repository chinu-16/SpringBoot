package com.example.thyemeleaf.Service;

import com.example.thyemeleaf.Entity.Role;

import java.util.List;

public interface RoleService {
    List<Role> getAllRoles();
}
