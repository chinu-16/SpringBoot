package com.example.thyemeleaf.Controller;

import com.example.thyemeleaf.Repository.UserRepository;
import com.example.thyemeleaf.Service.RoleService;
import com.example.thyemeleaf.Service.UserService;
import com.fasterxml.jackson.databind.Module;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.thyemeleaf.Entity.User;

import java.util.List;


@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleService roleService;

    @GetMapping("/login")
    private String showlogin(){
        return "login";
    }
    @PostMapping("/login")
    private String login(@RequestParam String username, @RequestParam String password, Model model){
        User user = userService.login(username,password);
        if(user != null){
            model.addAttribute("user",user);
            return "success";

        }
        else {
            model.addAttribute("error","Invalid username or password");
            return "login";
        }
    }

    @GetMapping("/Register")
    private String showRegistration(){
        return "Register";
    }

    @PostMapping("/Register")
    private String registration(@RequestParam String firstname,@RequestParam String lastname ,@RequestParam String email, @RequestParam String password, Model model){
        Boolean isRegisterd = userService.adduser(firstname,lastname,email,password);

        if(isRegisterd){
            model.addAttribute("welcome","Registration Successful");
            return "redirect:/login";
        }
        else {
            model.addAttribute("error ","user already exists");
            return "Register";
        }
    }
    @GetMapping("/success")
    public String success() {
        return "success";
    }





}
