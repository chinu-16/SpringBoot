package com.example.thyemeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThyemeleafApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThyemeleafApplication.class, args);
    }

}
