package com.example.thyemeleaf.Service;

import com.example.thyemeleaf.Entity.Role;
import com.example.thyemeleaf.Entity.User;
import com.example.thyemeleaf.Repository.RoleRepository;
import com.example.thyemeleaf.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;


    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;

    }



    @Override
    public List<User> getAllusers() {
        return userRepository.findAll();
    }

    @Override
    public User login(String username, String password) {
        return userRepository.findByEmail(username);
    }

    @Override
    public Boolean adduser(String firstname, String lastname, String email, String password) {
        if(userRepository.findByEmail(email) != null) {
            return true;
        }
        User user = new User();
        user.setFirstname(firstname);
        user.setLastname(lastname);
        user.setEmail(email);
        user.setPassword(password);
        userRepository.save(user);
        return false;
    }
}
