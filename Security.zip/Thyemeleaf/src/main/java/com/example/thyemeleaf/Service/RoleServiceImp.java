package com.example.thyemeleaf.Service;

import com.example.thyemeleaf.Entity.Role;
import com.example.thyemeleaf.Repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImp implements RoleService {

    @Autowired
    private RoleRepository roleRepository;


    public RoleServiceImp( RoleRepository roleRepository) {

        this.roleRepository = roleRepository;
    }


    @Override
    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }
}
