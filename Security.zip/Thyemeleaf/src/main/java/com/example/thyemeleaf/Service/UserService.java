package com.example.thyemeleaf.Service;

import com.example.thyemeleaf.Entity.User;

import java.util.List;

public interface UserService {






    List<User> getAllusers();

    User login(String username, String password);

    Boolean adduser(String firstname, String lastname, String email, String password);
}
