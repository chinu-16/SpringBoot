package com.example.demo.model;

public class Student {
    private String name;
    private int studentId;

    public Student(String name, int studentId) {
        this.name = name;
        this.studentId = studentId;
    }

    // Method for issuing a book
    public void issueBook(Book book, Library library) {
        if (library.issueBook(book)) {
            System.out.println(name + " successfully issued " + book.getTitle());
        } else {
            System.out.println(book.getTitle() + " is not available.");
        }
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getStudentId() {
        return studentId;
    }
}
