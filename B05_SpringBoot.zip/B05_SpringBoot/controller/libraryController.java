package com.example.demo.controller;

import com.example.demo.model.Book;
import com.example.demo.model.Library;
import com.example.demo.model.Student;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/library")
public class LibraryController {
    private Library library = new Library();

    // Add a book to the library
    @PostMapping("/addBook")
    public String addBook(@RequestBody Book book) {
        library.addBook(book);
        return "Book added to library: " + book.getTitle();
    }

    // Issue a book to a student
    @PostMapping("/issueBook")
    public String issueBook(@RequestParam String bookTitle, @RequestBody Student student) {
        Book book = library.getBooks().stream()
                            .filter(b -> b.getTitle().equalsIgnoreCase(bookTitle))
                            .findFirst()
                            .orElse(null);

        if (book != null && book.isAvailable()) {
            student.issueBook(book, library);
            return "Issued " + book.getTitle() + " to " + student.getName();
        }
        return "Book is not available.";
    }

    // Display available books
    @GetMapping("/availableBooks")
    public List<Book> availableBooks() {
        return library.getBooks();
    }
}
