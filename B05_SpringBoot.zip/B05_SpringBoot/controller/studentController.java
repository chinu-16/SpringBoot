package com.example.demo.controller;

import com.example.demo.model.Student;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    private List<Student> students = new ArrayList<>();

    // Add a new student
    @PostMapping("/add")
    public String addStudent(@RequestBody Student student) {
        students.add(student);
        return "Student added: " + student.getName();
    }

    // Get a list of all students
    @GetMapping("/all")
    public List<Student> getAllStudents() {
        return students;
    }

    // Get a single student by ID
    @GetMapping("/{id}")
    public Student getStudent(@PathVariable int id) {
        return students.stream()
                       .filter(student -> student.getStudentId() == id)
                       .findFirst()
                       .orElse(null);
    }
}
