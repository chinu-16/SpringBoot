package com.example.demo.controller;

import com.example.demo.model.Book;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {
    private List<Book> books = new ArrayList<>();

    // Add a new book to the library
    @PostMapping("/add")
    public String addBook(@RequestBody Book book) {
        books.add(book);
        return "Book added: " + book.getTitle();
    }

    // Get a list of all books
    @GetMapping("/all")
    public List<Book> getAllBooks() {
        return books;
    }

    // Get a single book by title
    @GetMapping("/{title}")
    public Book getBook(@PathVariable String title) {
        return books.stream()
                    .filter(book -> book.getTitle().equalsIgnoreCase(title))
                    .findFirst()
                    .orElse(null);
    }
}
