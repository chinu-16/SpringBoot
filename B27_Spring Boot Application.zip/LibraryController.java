//B27 Spring Boot Application

package com.example.prachi.controller;

import com.example.prachi.model.IssueRequest;
import com.example.prachi.model.book;
import com.example.prachi.model.student;
import org.springframework.web.bind.annotation.*;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.List;

@RestController
public class LibraryController {

    private List<book> bookList = new ArrayList<>();
    private List<student> studentList = new ArrayList<>();

    // Add a new book to the library
    @PostMapping("/library/addBook")
    public String createBook(@RequestBody book book) {
        bookList.add(book);
        return "Book '" + book.getTitle() + "' added to the library!";
    }


    // Issue a book to a student
    @PostMapping("/issueBook")
    public String issueBook(@RequestBody IssueRequest request) {
        String bookTitle = request.getBookTitle();
        String studentName = request.getStudentName();

        book bookToIssue = null;
        for (book book : bookList) {
            if (book.getTitle().equalsIgnoreCase(bookTitle)) {
                bookToIssue = book;
                break;
            }
        }

        if (bookToIssue == null) {
            return "Book '" + bookTitle + "' not found in the library!";
        }

        if (bookToIssue.isIssued()) {
            return "Book '" + bookTitle + "' is already issued to another student!";
        }

        for (student student : studentList) {
            if (student.getName().equalsIgnoreCase(studentName)) {
                bookToIssue.setIssued(true);
                student.setIssuedBook(bookToIssue);
                return "Book '" + bookTitle + "' issued to student '" + studentName + "' successfully!";
            }
        }

        return "Student '" + studentName + "' not found!";
    }

    // Check availability of a book
    @GetMapping("/checkBookAvailability/{title}")
    public String checkBookAvailability(@PathVariable String title) {
        for (book book : bookList) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                if (book.isIssued()) {
                    return "Book '" + title + "' is currently issued.";
                } else {
                    return "Book '" + title + "' is available.";
                }
            }
        }
        return "Book '" + title + "' not found!";
    }



    // Delete a book entry
    @DeleteMapping("/deleteLibraryBook/{title}")
    public String deleteBook(@PathVariable String title) {
        for (book book : bookList) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                bookList.remove(book);
                return "Book '" + title + "' deleted successfully!";
            }
        }
        return "Book '" + title + "' not found!";
    }

    // Update a student's name
    @PutMapping("/updateStudentafterReturningBook/{name}")
    public String updateStudent(@PathVariable String name, @RequestBody student updatedStudent) {
        for (student student : studentList) {
            if (student.getName().equalsIgnoreCase(name)) {
                student.setName(updatedStudent.getName()); // Update student name
                return "Student '" + name + "' updated successfully!";
            }
        }
        return "Student '" + name + "' not found!";
    }

    // Delete an issued book entry and the corresponding student entry
    @DeleteMapping("/deleteStudentAndBookEntry/{studentName}")
    public String deleteStudentAndBookEntry(@PathVariable String studentName) {
        for (student student : studentList) {
            if (student.getName().equalsIgnoreCase(studentName)) {
                book issuedBook = student.getIssuedBook();
                if (issuedBook != null) {
                    issuedBook.setIssued(false); // Mark book as available
                }
                studentList.remove(student);
                return "Student '" + studentName + "' and issued book entry deleted successfully!";
            }
        }
        return "Student '" + studentName + "' not found!";
    }

    // Get the list of all books
    @GetMapping("/getAllBooks")
    public List<book> getAllBooks() {
        return bookList;
    }

    // Get the list of all students
    @GetMapping("/getAllStudents")
    public List<student> getAllStudents() {
        return studentList;
    }
}
