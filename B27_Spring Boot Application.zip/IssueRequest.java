//B27 Spring Boot Application

package com.example.prachi.model;

public class IssueRequest {
    private String bookTitle;
    private String studentName;

    // Constructors
    public IssueRequest() {}

    public IssueRequest(String bookTitle, String studentName) {
        this.bookTitle = bookTitle;
        this.studentName = studentName;
    }

    // Getters and Setters
    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
}
