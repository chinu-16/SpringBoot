//B27 Spring Boot Application

package com.example.prachi.model;

public class book {
    private int accessionNumber;
    private Long id;

    private String title;
    private boolean issued;
    private double price;


    public void setAccessionNumber(int accessionNumber) {
        this.accessionNumber = accessionNumber;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getAccessionNumber() {
        return accessionNumber;
    }

    public double getPrice() {
        return price;
    }



    public book() {}

    public book(String title) {
        this.title = title;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isIssued() {
        return issued;
    }

    public void setIssued(boolean issued) {
        this.issued = issued;
    }

}
