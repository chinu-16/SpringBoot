//B27 Spring Boot Application

package com.example.prachi.model;

public class librarian {

    private String id;
    private String name;
    private String bookavailable;

    public librarian() {
    }

    public librarian(String id, String name, String subject) {
        this.id = id;
        this.name = name;
        this.bookavailable = subject;
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject() {
        return bookavailable;
    }

    public void setSubject(String subject) {
        this.bookavailable = subject;
    }
}

