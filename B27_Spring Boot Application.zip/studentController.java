//B27 Spring Boot Application

package com.example.prachi.controller;

import com.example.prachi.model.student;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class studentController {
    private List<student> studentList = new ArrayList<>();
    @PostMapping("/createNewStudent")
    public String createStudent(@RequestBody student student) {
        studentList.add(student);
        return "Student created successfully!";
    }

    @GetMapping("/getStudent")
    public List<student> getStudents() {
        return studentList;
    }
    @PutMapping("/updateStudent/{name}")
    public String updateStudent(@PathVariable String name, @RequestBody student updatedStudent) {
        for (student s : studentList) {
            if (s.getName().equalsIgnoreCase(name)) {
                s.setName(updatedStudent.getName()); // Update student name
                return "Student updated successfully!";
            }
        }
        return "Student with name '" + name + "' not found!";
    }
    @DeleteMapping("/deleteStudent/{name}")
    public String deleteStudent(@PathVariable String name) {
        for (student s : studentList) {
            if (s.getName().equalsIgnoreCase(name)) {
                studentList.remove(s);
                return "Student with name '" + name + "' deleted successfully!";
            }
        }
        return "Student with name '" + name + "' not found!";
    }

}
