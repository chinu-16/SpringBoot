//B27 Spring Boot Application

package com.example.prachi.model;


public class student {
    private int prn;
    private String name;
    private int age;
    private book issuedBook;
    public student(int prn, String name, int age) {
        this.prn = prn;
        this.name = name;
        this.age = age;

    }
    public int getPrn() {
        return prn;
    }
    public void setPrn(int prn) {
        this.prn = prn;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    public book getIssuedBook() {
        return issuedBook;
    }

    public void setIssuedBook(book issuedBook) {
        this.issuedBook = issuedBook;
    }
}