//B27 Spring Boot Application

package com.example.prachi.controller;

import com.example.prachi.model.book;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class bookController {

    private List<book> bookList = new ArrayList<>();
    @PostMapping("/addNewBook")
    public String createBook(@RequestBody book book) {
        bookList.add(book);
        return "Book created successfully!";
    }

    @PutMapping("/updateBook/{title}")
    public String updateBook(@PathVariable String title, @RequestBody book updatedBook) {
        for (book b : bookList) {
            if (b.getTitle().equalsIgnoreCase(title)) {
                b.setTitle(updatedBook.getTitle()); // Update fields here
                return "Book updated successfully!";
            }
        }
        return "Book with title '" + title + "' not found!";
    }

    @GetMapping("/getNewBook")
    public List<book> getNewBook() {
        return bookList;
    }
    @DeleteMapping("/deleteBook/{title}")
    public String deleteBook(@PathVariable String title) {
        for (book b : bookList) {
            if (b.getTitle().equalsIgnoreCase(title)) {
                bookList.remove(b);
                return "Book with title '" + title + "' deleted successfully!";
            }
        }
        return "Book with title '" + title + "' not found!";
    }

}


