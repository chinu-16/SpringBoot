package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.controller;

import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Services.LibrarianService;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.Librarian;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/Librarian")
public class LibrarianController {

    @Autowired
    private LibrarianService librarianService;

    @PostMapping("/issue/{bookId}/{studentPrn}")
    public ResponseEntity<String> issueBook(@PathVariable Long bookId, @PathVariable Long studentPrn) {
        String result = librarianService.issueBook(bookId, studentPrn);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/collect/{bookId}/{studentPrn}")
    public ResponseEntity<String> unissueBook(@PathVariable Long bookId, @PathVariable Long studentPrn) {
        String result = librarianService.unIssueBook(bookId,studentPrn);
        return ResponseEntity.ok(result);
    }

    @GetMapping
    public ResponseEntity<List<Librarian>> findAll() {
        List<Librarian> librarians = librarianService.findAll();
        return ResponseEntity.ok(librarians);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Librarian> findById(@PathVariable String id) {
        Optional<Librarian> librarianOptional = librarianService.findById(id);
        return librarianOptional.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Librarian> save(@RequestBody Librarian librarian) {
        Librarian savedLibrarian = librarianService.save(librarian);
        return ResponseEntity.ok(savedLibrarian);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable String id) {
        librarianService.deleteById(id);
        return ResponseEntity.noContent().build();
    }


}
