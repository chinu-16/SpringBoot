package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long prnNo;

    private String name;
    private String branch;
    private String year;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Book> assignedBooks = new ArrayList<>();
}
