package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Services;

import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Repository.StudentRepository;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentByPrn(Long prnNo) {
        return studentRepository.findById(prnNo).orElse(null);
    }

    public Student addStudent(Student student) {
        return studentRepository.save(student);
    }

    public Student updateStudent(Long prnNo, Student updatedStudent) {
        updatedStudent.setPrnNo(prnNo);
        return studentRepository.save(updatedStudent);
    }

    public String deleteStudent(Long prnNo) {
        studentRepository.deleteById(prnNo);
        return "Student deleted successfully";
    }
}
