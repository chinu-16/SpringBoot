package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.controller;

import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Services.StudentService;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/")
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    @GetMapping("/{prnNo}")
    public Student getStudentByPrn(@PathVariable Long prnNo) {
        return studentService.getStudentByPrn(prnNo);
    }

    @PostMapping("/add")
    public Student addStudent(@RequestBody Student student) {
        return studentService.addStudent(student);
    }

    @PutMapping("/update/{prnNo}")
    public Student updateStudent(@PathVariable Long prnNo, @RequestBody Student updatedStudent) {
        return studentService.updateStudent(prnNo, updatedStudent);
    }

    @DeleteMapping("/delete/{prnNo}")
    public String deleteStudent(@PathVariable Long prnNo) {
        return studentService.deleteStudent(prnNo);
    }
}
