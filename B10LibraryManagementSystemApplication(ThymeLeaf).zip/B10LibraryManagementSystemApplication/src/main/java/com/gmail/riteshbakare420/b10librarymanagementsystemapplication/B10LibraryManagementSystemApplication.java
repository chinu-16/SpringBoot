package com.gmail.riteshbakare420.b10librarymanagementsystemapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B10LibraryManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(B10LibraryManagementSystemApplication.class, args);
	}

}
