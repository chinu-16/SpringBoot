package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Services;

import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Repository.BookRepository;
//import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Repository.IssueBookRepository;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Repository.LibrarianRepository;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Repository.StudentRepository;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.Book;
//import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.IssueBook;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.Librarian;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LibrarianService {

    @Autowired
    private LibrarianRepository librarianRepository;

//    @Autowired
//    private IssueBookRepository issueBookRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private BookRepository bookRepository;

    public String issueBook(Long bookId, Long studentPrn) {
        Optional<Book> bookOptional = bookRepository.findById(bookId);
        Optional<Student> studentOptional = studentRepository.findById(studentPrn);

        if (bookOptional.isPresent() && studentOptional.isPresent()) {
            Book book = bookOptional.get();
            Student student = studentOptional.get();
            System.out.println("Book Name: " + book.getBookName());
            System.out.println("Student Name: " + student.getName());

//            IssueBook issueBook = new IssueBook();
//            issueBook.setBookId(bookId);
//            issueBook.setStudentPrn(studentPrn);
//            issueBookRepository.save(issueBook);

            student.getAssignedBooks().add(book);

            studentRepository.save(student);
            return "Book issued successfully.";
        } else {
            return "Book or Student not found.";
        }
    }

    public String unIssueBook(Long bookId, Long studentPrn) {
        Optional<Book> bookOptional = bookRepository.findById(bookId);
        Optional<Student> studentOptional = studentRepository.findById(studentPrn);
        if (bookOptional.isPresent() && studentOptional.isPresent()) {
            Book book = bookOptional.get();
            Student student = studentOptional.get();

            student.getAssignedBooks().remove(book);
            studentRepository.save(student);

            return "unIssued book successfully for student with prn: " + student.getPrnNo();
        }
        else {
            return "Book or Student not found.";
        }
    }


    public List<Librarian> findAll() {
        return librarianRepository.findAll();
    }

    public Optional<Librarian> findById(String id) {
        return librarianRepository.findById(id);
    }

    public Librarian save(Librarian librarian) {
        return librarianRepository.save(librarian);
    }

    public void deleteById(String id) {
        librarianRepository.deleteById(id);
    }
}
