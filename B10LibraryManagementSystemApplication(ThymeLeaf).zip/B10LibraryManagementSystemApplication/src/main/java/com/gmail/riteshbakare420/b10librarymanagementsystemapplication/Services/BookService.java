package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Services;

import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Repository.BookRepository;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Book getBookById(Long bookId) {
        return bookRepository.findById(bookId).orElse(null);
    }

    public Book addBook(Book book) {
        return bookRepository.save(book);
    }

    public Book updateBookDetails(Long bookId, Book updatedBook) {
        updatedBook.setBookId(bookId);
        return bookRepository.save(updatedBook);
    }

    public String deleteBook(Long bookId) {
        bookRepository.deleteById(bookId);
        return "Book deleted successfully";
    }
}
