package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.controller;


import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Services.BookService;
import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/")
    public String getAllBooks(Model model) {
        List<Book> books = bookService.getAllBooks();
        model.addAttribute("books", books);
        return "books"; // books.html
    }

    @GetMapping("/{bookId}")
    public String getBookById(@PathVariable Long bookId, Model model) {
        Book book = bookService.getBookById(bookId);
        model.addAttribute("book", book);
        return "book-details"; // book-details.html
    }

    @GetMapping("/add")
    public String showAddBookForm(Model model) {
        model.addAttribute("book", new Book());
        return "add-book";
    }

    @PostMapping("/add")
    public String addBook(@ModelAttribute Book book) {
        bookService.addBook(book);
        return "redirect:/books/";
    }

    @GetMapping("/update/{bookId}")
    public String showUpdateBookForm(@PathVariable Long bookId, Model model) {
        Book book = bookService.getBookById(bookId);
        model.addAttribute("book", book);
        return "update-book";
    }

    @PostMapping("/update/{bookId}")
    public String updateBookDetails(@PathVariable Long bookId, @ModelAttribute Book updatedBook) {
        bookService.updateBookDetails(bookId, updatedBook);
        return "redirect:/books/";
    }

    @GetMapping("/delete/{bookId}")
    public String deleteBook(@PathVariable Long bookId) {
        bookService.deleteBook(bookId);
        return "redirect:/books/";
    }
}

//@RestController
//@RequestMapping("/books")
//public class BookController {
//
//    @Autowired
//    private BookService bookService;
//
//    @GetMapping("/")
//    public List<Book> getAllBooks() {
//        return bookService.getAllBooks();
//    }
//
//    @GetMapping("/{bookId}")
//    public Book getBookById(@PathVariable Long bookId) {
//        return bookService.getBookById(bookId);
//    }
//
//    @PostMapping("/add")
//    public Book addBook(@RequestBody Book book) {
//        return bookService.addBook(book);
//    }
//
//    @PutMapping("/update/{bookId}")
//    public Book updateBookDetails(@PathVariable Long bookId, @RequestBody Book updatedBook) {
//        return bookService.updateBookDetails(bookId, updatedBook);
//    }
//
//    @DeleteMapping("/delete/{bookId}")
//    public String deleteBook(@PathVariable Long bookId) {
//        return bookService.deleteBook(bookId);
//    }
//}
