package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Services;

//import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Repository.IssueBookRepository;
//import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.IssueBook;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class IssueBookService {
//
//    @Autowired
//    private IssueBookRepository issueBookRepository;
//
//    public List<IssueBook> findAll() {
//        return issueBookRepository.findAll();
//    }
//
//    public Optional<IssueBook> findById(Long id) {
//        return issueBookRepository.findById(id);
//    }
//
//    public IssueBook save(IssueBook issueBook) {
//        return issueBookRepository.save(issueBook);
//    }
//
//    public void deleteById(Long id) {
//        issueBookRepository.deleteById(id);
//    }
//}