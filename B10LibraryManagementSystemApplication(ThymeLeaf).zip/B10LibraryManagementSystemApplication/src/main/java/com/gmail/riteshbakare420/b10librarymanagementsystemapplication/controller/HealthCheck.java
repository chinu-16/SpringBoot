package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/public")
public class HealthCheck {

    @GetMapping("/")
    String healthCheck() {
        return "Hello World";
    }

}
