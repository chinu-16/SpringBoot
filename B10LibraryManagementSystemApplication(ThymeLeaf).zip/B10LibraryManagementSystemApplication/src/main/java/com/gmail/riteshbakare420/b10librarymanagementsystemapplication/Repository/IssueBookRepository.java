package com.gmail.riteshbakare420.b10librarymanagementsystemapplication.Repository;

//import com.gmail.riteshbakare420.b10librarymanagementsystemapplication.models.IssueBook;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;

//@Repository
//public interface IssueBookRepository extends JpaRepository<IssueBook,Long> {
//}
